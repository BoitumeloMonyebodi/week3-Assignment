
def calculate_discount(price, discount_percent):
 #check if the discount is 20% or more
     if discount_percent >= 20:
         #calculate the discount amount
         discount_amount = price * (discount_percent / 100)
         #calculate the final price after discount
         final_price = price - discount_amount
         return final_price
     else:
         #if the discount is less than 20%, return the original price
         return price
     
