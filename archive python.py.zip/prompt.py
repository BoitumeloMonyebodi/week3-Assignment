
# Define the function to calculate the discounted price
def calculate_discount(price, discount_percent):
    if discount_percent > 0:
        return price - (price * discount_percent / 100)
    return price

# Prompt the user for the price and discount percentage
price = float(input("Enter the price of the item: "))
discount_percent = float(input("Enter the discount percentage: "))

# Call the function to calculate the final price
final_price = calculate_discount(price, discount_percent)

# Print the final price or the original price if no discount is applied
if final_price == price:
    print(f"No discount applied. The price is: ${price:.2f}")
else:
    print(f"The final price after discount is: ${final_price:.2f}")

# End of code 